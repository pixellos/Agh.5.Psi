Każdy miał swój punkt w 2.4 do poprawy.

Wymagania produktowe:

• użyteczności, -- Mateusz

• sprawnościowe:

-- efektywności, -- Mateusz

-- pamięci. --Mateusz 

• niezawodności, -- Kacper

• przenośności. -- Kacper



Wymagania organizacyjne:

• dostawy, -- KAMIL

• implementacyjne, -- KAMIL

• standardów--  -- Kacper


 Wymagania zewnętrzne: Wymagania zewnętrzne:

• współpracy,--ADAM

• etyczne,--ADAM

• prawne: -- KAMIL

 ochrony prywatności,--KAMIL

 wymagania zabezpieczeń.:--ADAM

About: Lato PSI-Faza-Okr-Wymagan-14-04-2019-V19 (1).pdf 


2.6 - Każdy uzupełniał WF dotyczących jego OA

Mniejsze: Poprawiono numerację, dodano spis dokumentów, poprawiono rysunki,
